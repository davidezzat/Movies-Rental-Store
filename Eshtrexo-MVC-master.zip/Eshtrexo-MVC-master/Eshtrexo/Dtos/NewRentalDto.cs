﻿using System.Collections.Generic;

namespace Eshtrexo.Dtos
{
    public class NewRentalDto
    {
        public int CustomerId { get; set; }
        public List<int> MovieIds { get; set; }
    }
}